<?php
/**
 * Template Name: Sports Category Hub
 * Description: Sports & Live Scores Hub
 *
 * @package ViralSon
 */
get_header();
?>

<main>
        
<!-- Sports Editorial Headline Banner -->
<section class="breaking-news" style="background-color: var(--dark-blue);">
    <div class="container breaking-container">
        <div class="breaking-label" style="background: var(--primary-blue); color: var(--white); font-weight: 700;">HEADLINE</div>
        <div class="breaking-text">
            <div class="breaking-text-content">Champions League: Northfield United completes sensational comeback against Riverside City to book European Final place!</div>
        </div>
    </div>
</section>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <span class="post-category" style="background: rgba(46, 204, 113, 0.15); color: #27ae60; margin-bottom: 0.8rem;">World Athletics &amp; Stadiums</span>
        <h1>Sports &amp; Arena Coverage</h1>
        <p>In-depth sports reporting, post-match breakdowns, tactical analysis, transfer markets, and exclusive athlete profiles across global leagues.</p>
    </div>
</section>

<!-- Sports Main Content -->
<section class="sports-content" style="padding-bottom: 3rem;">
    <div class="container">
        <!-- Sports Navigation Tabs -->
        <div class="sports-tabs" id="sportsTabs">
            <div class="tab active" data-tab="football"><i class="fas fa-futbol" style="margin-right: 6px;"></i> Football</div>
            <div class="tab" data-tab="basketball"><i class="fas fa-basketball-ball" style="margin-right: 6px;"></i> Basketball</div>
            <div class="tab" data-tab="tennis"><i class="fas fa-table-tennis" style="margin-right: 6px;"></i> Tennis</div>
            <div class="tab" data-tab="motorsport"><i class="fas fa-flag-checkered" style="margin-right: 6px;"></i> Motorsport</div>
            <div class="tab" data-tab="athletics"><i class="fas fa-running" style="margin-right: 6px;"></i> Athletics</div>
        </div>

        <!-- Main Content & Sidebar Grid -->
        <div class="news-container">
            <div class="news-main">
                
                <!-- ================= FOOTBALL TAB CONTENT ================= -->
                <div class="tab-content active" id="tab-football">
                    <!-- Featured Football Card -->
                    <article class="news-card featured" style="margin-bottom: 2.5rem;">
                        <div class="news-image">
                            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1522778119026-d647f0596c20%3Fauto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80?_a=BBFAAAAA0" alt="Football Stadium Match Celebration" loading="lazy">
                        </div>
                        <div class="news-content">
                            <span class="post-category" style="background: rgba(46, 204, 113, 0.15); color: #27ae60;">Champions League • Match Report</span>
                            <h2 class="news-title"><a href="../posts/united-late-winner/index.html">Late Winner Sends United Through to the Final in Dramatic Fashion</a></h2>
                            <p class="news-date">June 24, 2026 • By Daniel Okafor • 6 min read</p>
                            <p style="color: var(--text-light); margin-bottom: 1.2rem;">A stoppage-time strike sealed a remarkable comeback from two goals down, capping one of the most thrilling semi-finals in recent memory.</p>
                            <a href="../posts/united-late-winner/index.html" class="btn btn-green">Read Full Match Report</a>
                        </div>
                    </article>

                    <!-- Football Grid -->
                    <div class="sports-grid">
                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1517927033932-b3d18e61fb3a%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Transfer News" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(52, 152, 219, 0.15); color: var(--primary-blue);">Transfers</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;"><a href="../posts/united-late-winner/index.html">Record-Breaking Deal Agreed for Star Midfielder</a></h3>
                                <p class="news-date">June 22, 2026 • 4 min read</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1508098682722-e99c43a406b2%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="League Table" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(230, 126, 34, 0.15); color: #e67e22;">Domestic League</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;"><a href="../posts/united-late-winner/index.html">Title Race Tightens as Top Three Drop Points</a></h3>
                                <p class="news-date">June 21, 2026 • 5 min read</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Manager Press Conference" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(155, 89, 182, 0.15); color: #9b59b6;">Tactics</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;"><a href="../posts/united-late-winner/index.html">Tactical Shift That Changed the Entire Season</a></h3>
                                <p class="news-date">June 19, 2026 • 7 min read</p>
                            </div>
                        </div>
                    </div>

                    <!-- Athlete Spotlight -->
                    <div class="athlete-spotlight">
                        <div class="athlete-container">
                            <div class="athlete-image">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Daniel Okafor Player of the Month" loading="lazy">
                            </div>
                            <div class="athlete-info">
                                <h3>Daniel Okafor</h3>
                                <span class="athlete-tag">Player of the Month</span>
                                <p class="athlete-bio">With 11 goals in his last eight appearances, Daniel Okafor has become the most feared forward in European football. His blend of clinical positioning, explosive burst, and composure under pressure has electrified the title race.</p>
                                <div class="athlete-stats">
                                    <div class="stat">
                                        <div class="stat-value">24</div>
                                        <div class="stat-label">Goals</div>
                                    </div>
                                    <div class="stat">
                                        <div class="stat-value">9</div>
                                        <div class="stat-label">Assists</div>
                                    </div>
                                    <div class="stat">
                                        <div class="stat-value">8.7</div>
                                        <div class="stat-label">Avg Rating</div>
                                    </div>
                                </div>
                                <a href="../posts/united-late-winner/index.html" class="btn btn-green">Read Player Profile</a>
                            </div>
                        </div>
                    </div>

                    <!-- Upcoming Fixtures -->
                    <div class="fixtures-section">
                        <h3 class="section-title">Upcoming Fixtures</h3>
                        <ul class="fixtures-list">
                            <li class="fixture-item">
                                <div class="fixture-date">Sat, July 1</div>
                                <div class="fixture-match">Northfield United vs Riverside City</div>
                                <div class="fixture-venue">Northfield Arena, 17:30</div>
                            </li>
                            <li class="fixture-item">
                                <div class="fixture-date">Sun, July 2</div>
                                <div class="fixture-match">Real Marbella vs Costa del Sol</div>
                                <div class="fixture-venue">Estadio del Mar, 20:00</div>
                            </li>
                            <li class="fixture-item">
                                <div class="fixture-date">Tue, July 4</div>
                                <div class="fixture-match">Milano FC vs Torino Athletic</div>
                                <div class="fixture-venue">San Vittorio, 19:45</div>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- ================= BASKETBALL TAB CONTENT ================= -->
                <div class="tab-content" id="tab-basketball" style="display: none;">
                    <article class="news-card featured" style="margin-bottom: 2.5rem;">
                        <div class="news-image">
                            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1546519638-68e109498ffc%3Fauto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80?_a=BBFAAAAA0" alt="Basketball Finals Game" loading="lazy">
                        </div>
                        <div class="news-content">
                            <span class="post-category" style="background: rgba(230, 126, 34, 0.15); color: #e67e22;">Playoffs • Finals</span>
                            <h2 class="news-title"><a href="../posts/united-late-winner/index.html">Overtime Thriller Levels the Finals Series at 2-2</a></h2>
                            <p class="news-date">June 23, 2026 • 5 min read</p>
                            <p style="color: var(--text-light); margin-bottom: 1.2rem;">A clutch step-back three-pointer with 1.4 seconds remaining forced double overtime, where the home squad held on for an electric triumph.</p>
                            <a href="../posts/united-late-winner/index.html" class="btn btn-orange">Game Breakdown</a>
                        </div>
                    </article>

                    <div class="sports-grid">
                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1519861531473-9200262188bf%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Basketball Training" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(52, 152, 219, 0.15); color: var(--primary-blue);">Draft Combine</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">Top Prospects Shine at Pre-Draft Combine</h3>
                                <p class="news-date">June 21, 2026</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1504450758481-7338eba7524a%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Basketball Arena" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(46, 204, 113, 0.15); color: #27ae60;">Analysis</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">How Modern Zone Schemes Counter Perimeter Spacing</h3>
                                <p class="news-date">June 18, 2026</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1608245449230-4ac19066d2d0%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Basketball Court" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(231, 76, 60, 0.15); color: var(--red);">Injury Update</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">All-Star Point Guard Cleared for Crucial Game 5</h3>
                                <p class="news-date">June 16, 2026</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ================= TENNIS TAB CONTENT ================= -->
                <div class="tab-content" id="tab-tennis" style="display: none;">
                    <article class="news-card featured" style="margin-bottom: 2.5rem;">
                        <div class="news-image">
                            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1622279457486-62dcc4a431d6%3Fauto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80?_a=BBFAAAAA0" alt="Tennis Court Grand Slam" loading="lazy">
                        </div>
                        <div class="news-content">
                            <span class="post-category" style="background: rgba(46, 204, 113, 0.15); color: #27ae60;">Grand Slam Championship</span>
                            <h2 class="news-title">Five-Set Baseline Epic Sends 21-Year-Old Qualifier to First Major Semi-Final</h2>
                            <p class="news-date">June 22, 2026 • 5 min read</p>
                            <p style="color: var(--text-light); margin-bottom: 1.2rem;">After four hours and thirty-eight minutes of unrelenting rallies under the sun, the young qualifier completed the biggest upset of the tennis calendar.</p>
                            <a href="index.html" class="btn btn-green">View Tournament Draw</a>
                        </div>
                    </article>

                    <div class="sports-grid">
                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1554068865-24cecd4e34b8%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Tennis Serve" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(52, 152, 219, 0.15); color: var(--primary-blue);">Rankings</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">World Number One Ranking Battles Head to Centre Court</h3>
                                <p class="news-date">June 20, 2026</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1530915365347-e35b749a0381%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Tennis Stadium" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(155, 89, 182, 0.15); color: #9b59b6;">Technique</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">The Tactical Return of the Serve-and-Volley Masterclass</h3>
                                <p class="news-date">June 17, 2026</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ================= MOTORSPORT TAB CONTENT ================= -->
                <div class="tab-content" id="tab-motorsport" style="display: none;">
                    <article class="news-card featured" style="margin-bottom: 2.5rem;">
                        <div class="news-image">
                            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1503376780353-7e6692767b70%3Fauto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80?_a=BBFAAAAA0" alt="Racing Car on Track" loading="lazy">
                        </div>
                        <div class="news-content">
                            <span class="post-category" style="background: rgba(231, 76, 60, 0.15); color: var(--red);">Grand Prix • Race Report</span>
                            <h2 class="news-title">Pit Strategy Masterclass Delivers Shock Wet-Weather Victory</h2>
                            <p class="news-date">June 21, 2026 • 5 min read</p>
                            <p style="color: var(--text-light); margin-bottom: 1.2rem;">A daring early undercut to intermediate compound tyres in torrential rain propelled the underdogs onto the top step of the podium.</p>
                            <a href="index.html" class="btn" style="background: var(--red);">Read GP Debrief</a>
                        </div>
                    </article>

                    <div class="sports-grid">
                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1541348263662-e068662d82af%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Race Track" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(230, 126, 34, 0.15); color: #e67e22;">Qualifying</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">Pole Position Secured by Barely 0.032 Seconds</h3>
                                <p class="news-date">June 20, 2026</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1552519507-da3b142c6e3d%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Motorsport paddock" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(52, 152, 219, 0.15); color: var(--primary-blue);">Driver Market</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">Championship Contender Signs Multi-Year Contract Extension</h3>
                                <p class="news-date">June 18, 2026</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ================= ATHLETICS TAB CONTENT ================= -->
                <div class="tab-content" id="tab-athletics" style="display: none;">
                    <article class="news-card featured" style="margin-bottom: 2.5rem;">
                        <div class="news-image">
                            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1552674605-db6ffd4facb5%3Fauto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80?_a=BBFAAAAA0" alt="Running Track Record" loading="lazy">
                        </div>
                        <div class="news-content">
                            <span class="post-category" style="background: rgba(52, 152, 219, 0.15); color: var(--primary-blue);">Track &amp; Field • World Record</span>
                            <h2 class="news-title">World Record Shattered in Stunning 400m Diamond League Sprint</h2>
                            <p class="news-date">June 20, 2026 • 4 min read</p>
                            <p style="color: var(--text-light); margin-bottom: 1.2rem;">A masterfully paced acceleration around the top curve and an explosive final straight rewrote the global record books before a roaring stadium.</p>
                            <a href="index.html" class="btn">View Lap Telemetry</a>
                        </div>
                    </article>

                    <div class="sports-grid">
                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1461896836934-ffe607ba8211%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Marathon" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(46, 204, 113, 0.15); color: #27ae60;">Marathon</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">Course Record Broken at City Marathon by Two Minutes</h3>
                                <p class="news-date">June 18, 2026</p>
                            </div>
                        </div>

                        <div class="news-card">
                            <div class="news-image" style="height: 170px;">
                                <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1571008887538-b36bb32f4571%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Athlete Training" loading="lazy">
                            </div>
                            <div class="news-content" style="padding: 1.2rem;">
                                <span class="post-category" style="background: rgba(230, 126, 34, 0.15); color: #e67e22;">High Performance</span>
                                <h3 style="font-size: 1.15rem; margin-bottom: 0.4rem;">Inside the Biomechanical Lab of Olympic Sprinters</h3>
                                <p class="news-date">June 15, 2026</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Sports Sidebar -->
            <aside class="news-sidebar">
                <!-- Sidebar Google Ads Display Unit -->
                
                

<!-- Google Ads Scene: Sidebar Display Unit (300x250 / 300x600 Half-Page) -->
<div class="google-ad-wrapper sidebar-ad-wrapper" data-ad-type="sidebar">
    <div class="google-ad-header">
        <span class="ad-label">SPONSORED</span>
        <a href="https://adssettings.google.com/" target="_blank" rel="noopener noreferrer" class="adchoices-link" title="Ads by Google">
            <i class="fab fa-google" style="font-size: 0.7rem; margin-right: 2px;"></i> Ad
        </a>
    </div>

    <!-- Google AdSense Tag -->
    <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-9481237418920194" data-ad-slot="4920192831" data-ad-format="rectangle" data-full-width-responsive="true"></ins>

    <!-- Visual Ad Scene Display -->
    <div class="ad-creative-scene sidebar-scene">
        <div class="ad-scene-media">
            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1511707171634-5f897ff02aa9%3Fauto%3Dformat%26fit%3Dcrop%26w%3D400%26q%3D80?_a=BBFAAAAA0" alt="Google Hardware Showcase" loading="lazy">
            <span class="ad-sponsored-pill">Featured Hardware</span>
        </div>
        <div class="ad-scene-content">
            <h4 class="ad-scene-title">Google Pixel 9 Pro Fold</h4>
            <p class="ad-scene-desc">The thinnest foldable with Super Actua Flex displays and generative Gemini intelligence built right in.</p>
            <div class="ad-scene-footer">
                <span class="ad-price-tag">From $1,799</span>
                <a href="https://store.google.com/" target="_blank" rel="noopener noreferrer" class="ad-cta-btn small">Learn More</a>
            </div>
        </div>
    </div>
</div>




                <div class="sidebar-widget">
                    <h3 class="sidebar-title">Trending in Sports</h3>
                    <ul class="trending-list">
                        <li class="trending-item">
                            <a href="../posts/united-late-winner/index.html" class="trending-title">Late Winner Sends United Through to Champions League Final</a>
                            <div class="trending-meta"><span>Football</span> • <span>42.1K reads</span></div>
                        </li>
                        <li class="trending-item">
                            <a href="index3043.html?tab=basketball" class="trending-title">Playoff Finals Deadlocked 2-2 After Overtime Drama</a>
                            <div class="trending-meta"><span>Basketball</span> • <span>19.3K reads</span></div>
                        </li>
                        <li class="trending-item">
                            <a href="index0ff1.html?tab=tennis" class="trending-title">21-Year-Old Qualifier Advances to Major Semi-Final</a>
                            <div class="trending-meta"><span>Tennis</span> • <span>15.7K reads</span></div>
                        </li>
                        <li class="trending-item">
                            <a href="index7ffe.html?tab=motorsport" class="trending-title">Underdog Strategy Clinches Wet Weather Grand Prix</a>
                            <div class="trending-meta"><span>Motorsport</span> • <span>12.4K reads</span></div>
                        </li>
                    </ul>
                </div>

                <div class="sidebar-widget">
                    <h3 class="sidebar-title">Upcoming Tournaments</h3>
                    <ul class="trending-list">
                        <li class="trending-item">
                            <div style="font-weight: 700; color: var(--primary-blue); font-size: 0.85rem;">July 1, 2026</div>
                            <div style="font-weight: 600;">Champions League Final — National Stadium</div>
                        </li>
                        <li class="trending-item">
                            <div style="font-weight: 700; color: var(--orange); font-size: 0.85rem;">July 2, 2026</div>
                            <div style="font-weight: 600;">Coastal Grand Prix — Marina Circuit</div>
                        </li>
                        <li class="trending-item">
                            <div style="font-weight: 700; color: var(--green); font-size: 0.85rem;">July 8, 2026</div>
                            <div style="font-weight: 600;">National Athletics Championships — Olympic Stadium</div>
                        </li>
                    </ul>
                </div>

                <div class="sidebar-widget">
                    <h3 class="sidebar-title">Sports Digest</h3>
                    <p style="font-size: 0.9rem; color: var(--text-light); margin-bottom: 1rem;">
                        Get daily match previews, tactical analysis, transfer updates, and fixture schedules delivered each morning.
                    </p>
                    <form onsubmit="event.preventDefault(); alert('Subscribed to sports digest!'); this.reset();">
                        <input type="email" class="form-control" placeholder="Your email address" required="" style="margin-bottom: 0.8rem;">
                        <button type="submit" class="btn btn-green" style="width: 100%;">Subscribe to Sports</button>
                    </form>
                </div>
            </aside>
        </div>
    </div>
</section>

<!-- Sports Tab Switching Script -->
<script>
    (function() {
        const tabs = document.querySelectorAll('.sports-tabs .tab');
        const contents = document.querySelectorAll('.news-main .tab-content');

        function switchTab(tabId) {
            tabs.forEach(tab => {
                if (tab.getAttribute('data-tab') === tabId) {
                    tab.classList.add('active');
                } else {
                    tab.classList.remove('active');
                }
            });

            contents.forEach(content => {
                if (content.id === `tab-${tabId}`) {
                    content.style.display = 'block';
                    content.classList.add('active');
                } else {
                    content.style.display = 'none';
                    content.classList.remove('active');
                }
            });

            try {
                const url = new URL(window.location.href);
                url.searchParams.set('tab', tabId);
                window.history.replaceState({}, '', url.toString());
            } catch (e) {}
        }

        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                switchTab(tabId);
            });
        });

        // Check for URL query param e.g. ?tab=motorsport
        const urlParams = new URLSearchParams(window.location.search);
        const initialTab = urlParams.get('tab');
        if (initialTab && document.getElementById(`tab-${initialTab}`)) {
            switchTab(initialTab);
        }
    })();
</script>

    </main>

<?php get_footer(); ?>
