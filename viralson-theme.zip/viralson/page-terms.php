<?php
/**
 * Template Name: Terms of Service
 * Description: Terms and Conditions
 *
 * @package ViralSon
 */
get_header();
?>

<main>
        
<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <span class="post-category" style="background:#e8f4fc; color:#2980b9; margin-bottom: 0.8rem;">Legal &amp; Policy</span>
        <h1>Terms and Conditions</h1>
        <p>Please read these terms carefully before using Viral Son. By accessing or using our website, you agree to be bound by these terms.</p>
        <div class="last-updated">
            <i class="far fa-calendar-check"></i>
            <span>Last Updated: June 25, 2023 (Verified Current)</span>
        </div>
    </div>
</section>

<!-- Intro Notice -->
<section class="intro-notice">
    <div class="container">
        <div class="notice-box">
            <i class="fas fa-info-circle"></i>
            <div>
                <h3>Agreement to Terms</h3>
                <p>These Terms and Conditions ("Terms") govern your access to and use of the Viral Son website, mobile applications, newsletters, and related digital services (collectively, the "Services"). By accessing or using the Services, you confirm that you accept these Terms and agree to comply with them. If you do not agree, please discontinue use of the Services immediately.</p>
            </div>
        </div>
    </div>
</section>

<!-- Legal Content -->
<section class="legal-section">
    <div class="container legal-container">

        <!-- Table of Contents Sidebar -->
        <aside class="toc" aria-label="Table of Contents">
            <h3 class="toc-title"><i class="fas fa-list-ul"></i> On This Page</h3>
            <ul class="toc-list">
                <li><a href="#section-1" class="toc-link active">1. Definitions</a></li>
                <li><a href="#section-2" class="toc-link">2. Eligibility</a></li>
                <li><a href="#section-3" class="toc-link">3. Use of the Services</a></li>
                <li><a href="#section-4" class="toc-link">4. Accounts &amp; Registration</a></li>
                <li><a href="#section-5" class="toc-link">5. Intellectual Property</a></li>
                <li><a href="#section-6" class="toc-link">6. User Content</a></li>
                <li><a href="#section-7" class="toc-link">7. Prohibited Conduct</a></li>
                <li><a href="#section-8" class="toc-link">8. Third-Party Links</a></li>
                <li><a href="#section-9" class="toc-link">9. Downloads &amp; Media</a></li>
                <li><a href="#section-10" class="toc-link">10. Disclaimers</a></li>
                <li><a href="#section-11" class="toc-link">11. Limitation of Liability</a></li>
                <li><a href="#section-12" class="toc-link">12. Indemnification</a></li>
                <li><a href="#section-13" class="toc-link">13. Termination</a></li>
                <li><a href="#section-14" class="toc-link">14. Governing Law</a></li>
                <li><a href="#section-15" class="toc-link">15. Changes to Terms</a></li>
                <li><a href="#section-16" class="toc-link">16. Contact Information</a></li>
            </ul>
        </aside>

        <!-- Legal Body -->
        <article class="legal-body">
            <p class="legal-intro">Welcome to Viral Son. These Terms and Conditions set out the rules governing your use of our website and services. We have written them in plain language wherever possible, but please read them thoroughly. If anything is unclear, you are welcome to contact our legal team using the details in Section 16.</p>

            <!-- 1. Definitions -->
            <section class="legal-block" id="section-1">
                <h2><span class="legal-number">1</span> Definitions</h2>
                <p>In these Terms, the following words have the meanings set out below:</p>

                <div class="def-grid">
                    <div class="def-card">
                        <h4>"Viral Son" / "We" / "Us"</h4>
                        <p>Refers to Viral Son and its affiliates, editorial team, employees, and agents operating the Services.</p>
                    </div>
                    <div class="def-card">
                        <h4>"User" / "You"</h4>
                        <p>Any individual, visitor, or entity accessing or using the Services in any capacity.</p>
                    </div>
                    <div class="def-card">
                        <h4>"Services"</h4>
                        <p>The Viral Son website, mobile apps, newsletters, community discussion groups, and all associated media features.</p>
                    </div>
                    <div class="def-card">
                        <h4>"Content"</h4>
                        <p>All text, images, videos, audio tracks, downloads, code, designs, and other materials made available through the Services.</p>
                    </div>
                    <div class="def-card">
                        <h4>"User Content"</h4>
                        <p>Any material you submit, post, upload, or transmit through the Services, including comments, story tips, and community messages.</p>
                    </div>
                    <div class="def-card">
                        <h4>"Downloadable Media"</h4>
                        <p>Digital files such as music tracks, audio samples, wallpapers, documents, or graphics made available for download.</p>
                    </div>
                </div>
            </section>

            <!-- 2. Eligibility -->
            <section class="legal-block" id="section-2">
                <h2><span class="legal-number">2</span> Eligibility</h2>
                <p>To use the Services, you must be at least 13 years of age. If you are under 18, you may only use the Services with the involvement and explicit consent of a parent or legal guardian.</p>
                <p>By using the Services, you represent and warrant that:</p>
                <ul>
                    <li>You have the legal capacity to enter into a binding agreement with Viral Son;</li>
                    <li>You are not barred from using the Services under any applicable regional or international laws; and</li>
                    <li>All registration or inquiry information you submit is accurate, current, and complete.</li>
                </ul>
                <div class="callout info">
                    <i class="fas fa-info-circle"></i>
                    <p>If you are using the Services on behalf of a company, organization, or institution, you represent and warrant that you possess full legal authority to bind that entity to these Terms.</p>
                </div>
            </section>

            <!-- 3. Use of the Services -->
            <section class="legal-block" id="section-3">
                <h2><span class="legal-number">3</span> Use of the Services</h2>
                <p>Viral Son grants you a limited, non-exclusive, non-transferable, revocable licence to access and enjoy the Services for personal, non-commercial purposes, subject to full compliance with these Terms.</p>

                <h3>3.1 Permitted Use</h3>
                <p>You may:</p>
                <ul>
                    <li>Read, view, bookmark, and share links to our articles, reviews, and editorial features;</li>
                    <li>Download media where an official download option is expressly provided (such as promotional music tracks);</li>
                    <li>Participate constructively in public comments, reader surveys, and community discussions; and</li>
                    <li>Subscribe to newsletters, digests, and push updates.</li>
                </ul>

                <h3>3.2 Restrictions</h3>
                <p>You may not:</p>
                <ul>
                    <li>Reproduce, republish, sell, syndicate, or redistribute our Content without prior written permission;</li>
                    <li>Use automated systems (bots, scrapers, crawlers) to access, harvest, or extract data from the Services;</li>
                    <li>Attempt to gain unauthorized access to any part of the Services, servers, databases, or cloud infrastructure;</li>
                    <li>Interfere with the proper functioning or security of the Services, including introducing viruses, worms, or malicious code; or</li>
                    <li>Frame, mirror, deep-link, or misrepresent any portion of the Services as your own creation.</li>
                </ul>
            </section>

            <!-- 4. Accounts & Registration -->
            <section class="legal-block" id="section-4">
                <h2><span class="legal-number">4</span> Accounts &amp; Registration</h2>
                <p>Certain features of the Services (including future writer portals and member privileges) may require registration. You agree to:</p>
                <ul>
                    <li>Provide accurate, current, and complete information during registration or newsletter signup;</li>
                    <li>Maintain the confidential security of your credentials and access tokens;</li>
                    <li>Notify us immediately of any unauthorized use or security compromise of your account; and</li>
                    <li>Accept responsibility for all activities occurring under your credentials.</li>
                </ul>
                <div class="callout warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>You are strictly responsible for keeping your login credentials confidential. Viral Son staff will never ask for your password via email, SMS, or direct message.</p>
                </div>
            </section>

            <!-- 5. Intellectual Property -->
            <section class="legal-block" id="section-5">
                <h2><span class="legal-number">5</span> Intellectual Property</h2>
                <p>All Content on the Services — including articles, photographs, custom illustrations, infographics, graphics, logos, brand icons, audio clips, video clips, downloadable tracks, data compilations, layout architecture, and software — is the exclusive property of Viral Son or its licensed content partners and is protected by international copyright, trademark, and intellectual property laws.</p>

                <h3>5.1 Our Trademarks</h3>
                <p>The "Viral Son" name, the VS badge logo, and all related brand marks, slogans, design signatures, and service names are trademarks of Viral Son. You may not use these marks without prior written authorization.</p>

                <h3>5.2 Limited Licence for Citation and Social Sharing</h3>
                <p>You may share excerpts and links to our stories on social media, blogs, or educational papers, provided you include clear attribution to Viral Son along with an active hyperlink back to the original article permalink.</p>

                <div class="callout important">
                    <i class="fas fa-ban"></i>
                    <p>Wholesale scraping, mirroring, or republication of our full articles — including AI-spun or automated synopses presented without attribution — is strictly prohibited and subject to DMCA takedowns and legal enforcement.</p>
                </div>
            </section>

            <!-- 6. User Content -->
            <section class="legal-block" id="section-6">
                <h2><span class="legal-number">6</span> User Content &amp; Comments</h2>
                <p>Readers can submit comments, responses, story tips, and feedback. You retain ownership of your original User Content, but by submitting it you grant Viral Son an irrevocable, perpetual, worldwide, royalty-free, non-exclusive licence to display, format, quote, and distribute it across our platforms.</p>

                <h3>6.1 Your Responsibilities</h3>
                <p>You represent and warrant that your comments and submissions:</p>
                <ul>
                    <li>Do not infringe third-party intellectual property, privacy, or publicity rights;</li>
                    <li>Are not defamatory, discriminatory, harassing, threatening, sexually explicit, or unlawful;</li>
                    <li>Do not contain malware, phishing links, or unauthorized promotional spam; and</li>
                    <li>Comply with our community decency standards.</li>
                </ul>

                <h3>6.2 Community Moderation</h3>
                <p>Viral Son reserves the right (without obligation) to review, flag, moderate, edit, or remove any User Content at any time without notice. Readers may report comments for moderator review using the built-in Report button on individual comments.</p>
            </section>

            <!-- 7. Prohibited Conduct -->
            <section class="legal-block" id="section-7">
                <h2><span class="legal-number">7</span> Prohibited Conduct</h2>
                <p>When interacting with the Services, you agree never to:</p>
                <ol>
                    <li>Violate any applicable local, national, or international statute or regulation;</li>
                    <li>Impersonate any journalist, administrator, or public figure, or falsify affiliations;</li>
                    <li>Harass, stalk, abuse, or dox other community members or newsroom journalists;</li>
                    <li>Transmit unlawful, obscene, libelous, or racially offensive content;</li>
                    <li>Harvest email addresses or personal information from community boards without consent;</li>
                    <li>Post repetitive commercial advertisements, referral scams, or spam;</li>
                    <li>Bypass, alter, or tamper with security protocols, rate limiters, or firewalls; or</li>
                    <li>Engage in denial-of-service attempts or infrastructure overburdening.</li>
                </ol>
                <div class="callout important">
                    <i class="fas fa-gavel"></i>
                    <p>Serious violations of this section may lead to permanent IP bans, forfeiture of reader privileges, and formal referral to law enforcement authorities.</p>
                </div>
            </section>

            <!-- 8. Third-Party Links -->
            <section class="legal-block" id="section-8">
                <h2><span class="legal-number">8</span> Third-Party Links &amp; Advertisers</h2>
                <p>The Services frequently link to external reference sources, research papers, partner publications, and Google AdSense network advertisements. We provide these links solely for reader convenience and documentation.</p>
                <p>Viral Son holds no control over, and assumes no liability for, the content, privacy protocols, terms, or security of external websites. Following outbound links is conducted entirely at your own discretion.</p>
                <div class="callout info">
                    <i class="fas fa-external-link-alt"></i>
                    <p>We advise readers to examine the specific privacy declarations and terms of use of any third-party website they visit through outbound links.</p>
                </div>
            </section>

            <!-- 9. Downloads & Media -->
            <section class="legal-block" id="section-9">
                <h2><span class="legal-number">9</span> Downloads &amp; Media</h2>
                <p>Certain dedicated sections of the Services provide downloadable media, such as music MP3 releases, digital artwork, or whitepapers. The following terms govern all downloads:</p>
                <ul>
                    <li><strong>Personal &amp; Promotional Use:</strong> Downloadable audio tracks and wallpapers are provided strictly for personal non-commercial playback unless explicit commercial licensing is designated;</li>
                    <li><strong>No Redistribution:</strong> You may not bundle, resell, license, or upload our downloadable files to third-party file sharing hubs or streaming servers;</li>
                    <li><strong>Credit &amp; Metadata:</strong> Embedded ID3 tags, artist credits, cover art, and copyright metadata must remain fully intact;</li>
                    <li><strong>Artist Support:</strong> Where audio downloads are offered for promotional preview, we strongly encourage readers to support the recording artists via official streaming and tour channels.</li>
                </ul>
                <div class="callout warning">
                    <i class="fas fa-copyright"></i>
                    <p>If you are a copyright holder and believe any downloadable file or story infringes your rights, please reach out directly to <a href="mailto:legal@viralson.com" class="inline-link">legal@viralson.com</a> for expedited DMCA review.</p>
                </div>
            </section>

            <!-- 10. Disclaimers -->
            <section class="legal-block" id="section-10">
                <h2><span class="legal-number">10</span> Disclaimers</h2>
                <p>The Services are provided on an "as is" and "as available" basis without warranties of any variety, whether express or implied by law.</p>
                <p>To the fullest extent legally permissible, Viral Son disclaims all warranties, including:</p>
                <ul>
                    <li>Implied merchantability, fitness for a particular purpose, and non-infringement;</li>
                    <li>Uninterrupted, error-free, or continuously secure access to all platform features;</li>
                    <li>Absolute real-time accuracy, exhaustiveness, or completeness of breaking news headlines; and</li>
                    <li>Correction of every software defect or device incompatibility.</li>
                </ul>
                <div class="callout info">
                    <i class="fas fa-newspaper"></i>
                    <p><strong>Editorial Notice:</strong> Articles and lifestyle guides are published for informational, educational, and cultural entertainment purposes. They do not constitute formal medical, financial, or legal counsel. Always consult accredited professionals before taking consequential financial, medical, or legal steps.</p>
                </div>
            </section>

            <!-- 11. Limitation of Liability -->
            <section class="legal-block" id="section-11">
                <h2><span class="legal-number">11</span> Limitation of Liability</h2>
                <p>To the maximum extent permitted under governing law, Viral Son, its directors, editors, writers, technology partners, and contributors shall not be held liable for any indirect, incidental, special, exemplary, punitive, or consequential damages, including:</p>
                <ul>
                    <li>Loss of revenue, data, business opportunities, or goodwill;</li>
                    <li>Damages resulting from reliance upon news reports, reviews, or lifestyle suggestions;</li>
                    <li>Inability to access the website during maintenance windows or server downtime; or</li>
                    <li>Unauthorized interception of transmissions by malicious third parties.</li>
                </ul>
                <p>In jurisdictions where limitation of liability for incidental damages is restricted, our liability is capped at the minimum amount permitted under applicable law.</p>
            </section>

            <!-- 12. Indemnification -->
            <section class="legal-block" id="section-12">
                <h2><span class="legal-number">12</span> Indemnification</h2>
                <p>You agree to indemnify, defend, and hold harmless Viral Son and its affiliates, staff, contractors, and agents from any claims, liabilities, damages, losses, costs, or legal fees arising from:</p>
                <ul>
                    <li>Your misuse of or unauthorized activities on the Services;</li>
                    <li>Your violation of any provision contained in these Terms;</li>
                    <li>Your infringement of any third-party rights, including copyright or privacy; or</li>
                    <li>Any User Content you publish or transmit on our platform.</li>
                </ul>
            </section>

            <!-- 13. Termination -->
            <section class="legal-block" id="section-13">
                <h2><span class="legal-number">13</span> Termination &amp; Suspension</h2>
                <p>We reserve the right to suspend or terminate your access to the Services at our sole discretion, without prior notice, if we determine that you have violated these Terms or applicable regulations.</p>
                <p>You may discontinue your use of the Services at any time. Surviving clauses — including intellectual property rights, user content licences, disclaimers, liability limitations, and indemnification — remain in effect following termination.</p>
            </section>

            <!-- 14. Governing Law -->
            <section class="legal-block" id="section-14">
                <h2><span class="legal-number">14</span> Governing Law &amp; Dispute Resolution</h2>
                <p>These Terms shall be interpreted and governed in accordance with applicable laws, without giving effect to conflict of laws principles. The parties agree to resolve any dispute through informal good-faith consultation before initiating legal arbitration or litigation.</p>
                <div class="callout success">
                    <i class="fas fa-handshake"></i>
                    <p>We are dedicated to resolving reader concerns amicably and quickly. Please contact us at <a href="mailto:legal@viralson.com" class="inline-link">legal@viralson.com</a> with any dispute or grievance.</p>
                </div>
            </section>

            <!-- 15. Changes to Terms -->
            <section class="legal-block" id="section-15">
                <h2><span class="legal-number">15</span> Changes to These Terms</h2>
                <p>We may modify these Terms periodically to reflect updates in editorial policy, statutory requirements, or new site capabilities. Whenever significant updates occur, we will update the "Last Updated" timestamp at the top of this document.</p>
                <p>Your continued engagement with Viral Son following the publication of revised terms constitutes your binding acceptance of the updated conditions.</p>
            </section>

            <!-- 16. Contact Information -->
            <section class="legal-block" id="section-16">
                <h2><span class="legal-number">16</span> Contact Information</h2>
                <p>If you have any questions, legal notices, or feedback regarding these Terms, please contact our legal desk. We aim to respond within 24 to 48 business hours.</p>

                <div class="contact-box">
                    <h3><i class="fas fa-balance-scale"></i> Legal &amp; Compliance Team</h3>
                    <div class="contact-line">
                        <i class="fas fa-envelope"></i>
                        <span>Email: <a href="mailto:legal@viralson.com">legal@viralson.com</a></span>
                    </div>
                    <div class="contact-line">
                        <i class="fas fa-phone"></i>
                        <span>Phone: +1 (555) 123-4567</span>
                    </div>
                    <div class="contact-line">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Office: 123 Media Street, Digital City, DC 10001</span>
                    </div>
                    <div class="contact-line">
                        <i class="far fa-clock"></i>
                        <span>Hours: Monday – Friday, 9:00 AM – 6:00 PM EST</span>
                    </div>
                </div>

                <p>For general inquiries or story suggestions, please visit our <a href="../contact/index.html" class="inline-link">Contact Us page</a> or email <a href="mailto:editorial@viralson.com" class="inline-link">editorial@viralson.com</a>.</p>
            </section>

            <!-- Acknowledgment Callout -->
            <div class="callout success" style="margin-top: 2.5rem;">
                <i class="fas fa-check-circle"></i>
                <p><strong>Acknowledgment:</strong> By continuing to use the Viral Son Services, you acknowledge that you have read, understood, and agreed to be bound by these Terms and Conditions.</p>
            </div>
        </article>
    </div>
</section>

<!-- Back to Top Button -->
<button class="back-to-top" id="backToTop" aria-label="Back to top">
    <i class="fas fa-arrow-up"></i>
</button>

<script>
    (function() {
        // Smooth scroll for TOC links
        const tocLinks = document.querySelectorAll('.toc-link');
        tocLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                const target = document.querySelector(targetId);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                    tocLinks.forEach(l => l.classList.remove('active'));
                    this.classList.add('active');
                }
            });
        });

        // Scroll spy for TOC
        const legalBlocks = document.querySelectorAll('.legal-block');
        function updateActiveToc() {
            let current = '';
            const scrollPos = window.scrollY + 160;

            legalBlocks.forEach(block => {
                if (scrollPos >= block.offsetTop) {
                    current = block.getAttribute('id');
                }
            });

            if (current) {
                tocLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + current) {
                        link.classList.add('active');
                    }
                });
            }
        }

        // Back to top button
        const backToTop = document.getElementById('backToTop');
        function handleScroll() {
            if (window.scrollY > 450) {
                backToTop.classList.add('show');
            } else {
                backToTop.classList.remove('show');
            }
            updateActiveToc();
        }

        window.addEventListener('scroll', handleScroll, { passive: true });

        if (backToTop) {
            backToTop.addEventListener('click', function() {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        updateActiveToc();
    })();
</script>

    </main>

<?php get_footer(); ?>
