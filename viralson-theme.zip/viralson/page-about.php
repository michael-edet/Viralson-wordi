<?php
/**
 * Template Name: About Us Page
 * Description: About Viral Son Editorial & Team
 *
 * @package ViralSon
 */
get_header();
?>

<main>
        
<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <span class="post-category" style="margin-bottom: 0.8rem;">Our Mission</span>
        <h1>About Viral Son</h1>
        <p>A modern independent media and storytelling platform delivering curated news, technology reviews, lifestyle insights, and audio entertainment.</p>
    </div>
</section>

<div class="container">
    <div class="about-hero-grid" style="margin-bottom: 4rem;">
        <div>
            <h2 class="section-title">Who We Are</h2>
            <p style="font-size: 1.1rem; line-height: 1.8; color: var(--text-dark); margin-bottom: 1.5rem;">
                Founded with the belief that modern readers deserve journalism and cultural coverage that is both substantive and engaging, <strong>Viral Son</strong> bridges the gap between deep investigative analysis and accessible digital storytelling.
            </p>
            <p style="font-size: 1.05rem; line-height: 1.8; color: var(--text-light); margin-bottom: 1.5rem;">
                From climate summits and smartphone hardware breakthroughs to electronic music releases and mindful productivity frameworks, our editorial team brings you stories that inform, inspire, and spark conversation.
            </p>
            <div class="stats-counter-row">
                <div>
                    <h3 style="font-size: 2.2rem; color: var(--primary-blue); font-weight: 800;">1.2M+</h3>
                    <p style="color: var(--text-light); font-size: 0.95rem;">Monthly Global Readers</p>
                </div>
                <div>
                    <h3 style="font-size: 2.2rem; color: var(--primary-blue); font-weight: 800;">190+</h3>
                    <p style="color: var(--text-light); font-size: 0.95rem;">Countries Reached</p>
                </div>
                <div>
                    <h3 style="font-size: 2.2rem; color: var(--primary-blue); font-weight: 800;">50K+</h3>
                    <p style="color: var(--text-light); font-size: 0.95rem;">Community Members</p>
                </div>
            </div>
        </div>
        <div>
            <img src="https://res.cloudinary.com/Michael/image/fetch/f_auto,q_auto/https://images.unsplash.com/photo-1522071820081-009f0129c71c%3Fauto%3Dformat%26fit%3Dcrop%26w%3D800%26q%3D80?_a=BBFAAAAA0" alt="Viral Son Team" style="border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); width: 100%;" loading="lazy">
        </div>
    </div>

    <!-- Editorial Pillars -->
    <div style="margin-bottom: 4rem;">
        <h2 class="section-title center">Our Editorial Pillars</h2>
        <div class="posts-grid" style="margin-top: 2.5rem;">
            <div class="post-card" style="padding: 2rem;">
                <div style="font-size: 2.2rem; color: var(--primary-blue); margin-bottom: 1rem;"><i class="fas fa-bullseye"></i></div>
                <h3 style="font-size: 1.3rem; margin-bottom: 0.8rem; color: var(--dark-blue);">Integrity &amp; Rigor</h3>
                <p style="color: var(--text-light); font-size: 0.95rem;">Every fact, statistic, and technical review is cross-checked through original documentation and verified experts.</p>
            </div>

            <div class="post-card" style="padding: 2rem;">
                <div style="font-size: 2.2rem; color: var(--green); margin-bottom: 1rem;"><i class="fas fa-globe"></i></div>
                <h3 style="font-size: 1.3rem; margin-bottom: 0.8rem; color: var(--dark-blue);">Global Outlook</h3>
                <p style="color: var(--text-light); font-size: 0.95rem;">We report on technological, environmental, and cultural trends with international relevance across all continents.</p>
            </div>

            <div class="post-card" style="padding: 2rem;">
                <div style="font-size: 2.2rem; color: var(--purple); margin-bottom: 1rem;"><i class="fas fa-users"></i></div>
                <h3 style="font-size: 1.3rem; margin-bottom: 0.8rem; color: var(--dark-blue);">Community-Powered</h3>
                <p style="color: var(--text-light); font-size: 0.95rem;">Our comment spaces and discussion circles allow readers to contribute constructive ideas and feedback directly.</p>
            </div>
        </div>
    </div>

    <!-- Contact Box -->
    <div style="background: var(--card-bg); padding: clamp(1.5rem, 4vw, 3rem); border-radius: var(--radius-md); box-shadow: var(--shadow-sm); border: 1px solid var(--border-color); max-width: 800px; margin: 0 auto;">
        <h2 style="font-size: clamp(1.5rem, 3vw, 1.8rem); color: var(--dark-blue); margin-bottom: 0.5rem; text-align: center;">Get In Touch</h2>
        <p style="text-align: center; color: var(--text-light); margin-bottom: 2rem;">We are always open to journalistic collaborations, media sponsorships, and speaking opportunities.</p>
        <div class="contact-cards-grid">
            <div style="background: var(--light-blue); padding: 1.5rem; border-radius: var(--radius-sm);">
                <i class="fas fa-envelope" style="font-size: 1.6rem; color: var(--primary-blue); margin-bottom: 0.5rem;"></i>
                <h4 style="color: var(--dark-blue);">General Queries</h4>
                <p style="font-size: 0.95rem;">info@viralson.com</p>
            </div>
            <div style="background: var(--light-blue); padding: 1.5rem; border-radius: var(--radius-sm);">
                <i class="fas fa-newspaper" style="font-size: 1.6rem; color: var(--primary-blue); margin-bottom: 0.5rem;"></i>
                <h4 style="color: var(--dark-blue);">Press &amp; Editorial</h4>
                <p style="font-size: 0.95rem;">news@viralson.com</p>
            </div>
        </div>
    </div>
</div>

    </main>

<?php get_footer(); ?>
